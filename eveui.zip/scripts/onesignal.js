var OneSignal = window.OneSignal || [];
        OneSignal.push(["init", {
          appId: "3db00495-24c4-4a1b-bde7-2b1f7971df3a",
          autoRegister: true, /* Set to true to automatically prompt visitors */
          httpPermissionRequest: {
            enable: true
          },
          notifyButton: {
              enable: true /* Set to false to hide */
          }
        }]);